<?php
include('koneksi.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <meta name="description" content="" />
  <link href="assets/images/favicon/favicon.png" rel="icon" />
  <title>Artikel - KONIG GUARD BUREAU</title>

  <link
    rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=Roboto:wght@400;700&display=swap" />
  <link
    rel="stylesheet"
    href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" />
  <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

  <link rel="stylesheet" href="assets/css/bootstrap.css" />
  <link rel="stylesheet" href="assets/css/animation.css" />
  <link rel="stylesheet" href="assets/css/libraries.css" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>

<body>
  <div id="preloader">
    <div class="loader-container">
      <img
        src="assets/images/logo/logo.png"
        alt="Logo"
        class="preloader-logo" />
      <div class="progress-bar">
        <div class="progress" id="progress"></div>
      </div>
      <div class="loading-text">Loading</div>
    </div>
  </div>
  <div class="wrapper">
    <!-- =========================
        Header
    =========================== -->
    <header class="header header-transparent header-layout1">
      <nav class="navbar navbar-expand-lg sticky-navbar">
        <div class="container-fluid">
          <a class="navbar-brand" href="/">
            <img
              src="assets/images/logo/logo_terang.png"
              class="logo-light"
              alt="logo" />
            <img
              src="assets/images/logo/logo_terang.png"
              class="logo-dark"
              alt="logo" />
          </a>
          <!-- <div class="nav-logo">
              <img src="assets/images/logo/logo.png" alt="logo" />
              <a href="#" class="shimmer-text">KONIG GUARD BUREAU&#174;</a>
            </div> -->
          <button class="navbar-toggler" type="button">
            <span class="menu-lines"><span></span></span>
          </button>
          <div class="collapse navbar-collapse" id="mainNavigation">
            <ul class="navbar-nav mx-auto">
              <li class="nav__item">
                <a href="/" class="nav__item-link">Beranda</a>
              </li>
              <!-- /.nav-item -->
              <li class="nav__item has-dropdown">
                <a
                  href="#"
                  data-toggle="dropdown"
                  class="dropdown-toggle nav__item-link">Tentang Kami</a>
                <ul class="dropdown-menu">
                  <li class="nav__item">
                    <a href="siapa_kami" class="nav__item-link">Siapa Kami?</a>
                  </li>
                  <!-- /.nav-item -->
                  <li class="nav__item">
                    <a href="legalitas" class="nav__item-link">Legalitas Perusahaan</a>
                  </li>
                  <!-- /.nav-item -->
                  <li class="nav__item">
                    <a href="struktur" class="nav__item-link">Struktur Perusahaan</a>
                  </li>
                  <!-- /.nav-item -->
                  <li class="nav__item">
                    <a href="karir" class="nav__item-link">Karir</a>
                  </li>
                  <!-- /.nav-item -->
                </ul>
                <!-- /.dropdown-menu -->
              </li>
              <!-- /.nav-item -->
              <li class="nav__item has-dropdown">
                <a
                  href="#"
                  data-toggle="dropdown"
                  class="dropdown-toggle nav__item-link">Layanan Kami</a>
                <ul class="dropdown-menu wide-dropdown-menu">
                  <li class="nav__item">
                    <div class="row mx-0">
                      <div class="col-sm-6 dropdown-menu-col">
                        <a
                          href="jasa_keamanan"
                          class="nav__item-link dropdown-menu-title">Jasa Keamanan</a>
                        <ul class="nav flex-column">
                          <li class="nav__item">
                            <a
                              class="nav__item-link"
                              href="jasa_keamanan#jasa_security">Pengamanan (Satpam)</a>
                          </li>
                          <!-- /.nav-item -->
                          <li class="nav__item">
                            <a
                              class="nav__item-link"
                              href="jasa_keamanan#jasa_bodyguard">Bodyguard</a>
                          </li>
                          <!-- /.nav-item -->
                          <li class="nav__item">
                            <a
                              class="nav__item-link"
                              href="jasa_keamanan#jasa_pengamanan_event">Pengamanan Event</a>
                          </li>
                          <!-- /.nav-item -->
                          <li class="nav__item">
                            <a
                              class="nav__item-link"
                              href="jasa_keamanan#jasa_detektif_swasta">Detektif swasta</a>
                          </li>
                          <!-- /.nav-item -->
                        </ul>
                      </div>
                      <!-- /.col-sm-6 -->
                      <div class="col-sm-6 dropdown-menu-col">
                        <a
                          href="jasa_operasional"
                          class="nav__item-link dropdown-menu-title">Fasilitas & Operasional</a>
                        <ul class="nav flex-column">
                          <li class="nav__item">
                            <a
                              class="nav__item-link"
                              href="jasa_operasional#jasa_parkir">Pengelolaan Parkir</a>
                          </li>
                          <!-- /.nav-item -->
                          <li class="nav__item">
                            <a
                              class="nav__item-link"
                              href="jasa_operasional#jasa_driver">Jasa Driver</a>
                          </li>
                          <!-- /.nav-item -->
                          <li class="nav__item">
                            <a
                              class="nav__item-link"
                              href="jasa_operasional#jasa_cleaning_service">Cleaning Services</a>
                          </li>
                          <!-- /.nav-item -->
                          <li class="nav__item">
                            <a
                              class="nav__item-link"
                              href="jasa_operasional#jasa_pramubakti">Jasa Pramubakti</a>
                          </li>
                          <!-- /.nav-item -->
                          <li class="nav__item">
                            <a
                              class="nav__item-link"
                              href="jasa_operasional#jasa_pengacara">Jasa Pengacara</a>
                          </li>
                          <!-- /.nav-item -->
                          <!-- /.nav-item -->
                        </ul>
                      </div>
                      <!-- /.col-sm-6 -->
                    </div>
                    <!-- /.row -->
                  </li>
                  <!-- /.nav-item -->
                </ul>
              </li>
              <!-- /.nav-item -->

              <!-- /.nav-item -->
              <li class="nav__item has-dropdown">
                <a
                  href="#"
                  data-toggle="dropdown"
                  class="dropdown-toggle nav__item-link">Mitra &amp; Pelatihan</a>
                <ul class="dropdown-menu">
                  <li class="nav__item">
                    <a href="mitra_konig" class="nav__item-link">Mitra Pengamanan Kami</a>
                  </li>
                  <!-- /.nav-item -->
                  <li class="nav__item">
                    <a href="mitra_pelatihan" class="nav__item-link">Mitra Pelatihan</a>
                  </li>
                  <!-- /.nav-item -->
                  <li class="nav__item">
                    <a href="pelatihan_konig" class="nav__item-link">Pelatihan Khusus</a>
                  </li>
                  <!-- /.nav-item -->
                </ul>
                <!-- /.dropdown-menu -->
              </li>
              <!-- /.nav-item -->
              <li class="nav__item has-dropdown">
                <a
                  href="#"
                  data-toggle="dropdown"
                  class="dropdown-toggle nav__item-link active">Media & Informasi</a>
                <ul class="dropdown-menu">
                  <li class="nav__item">
                    <a href="artikel" class="nav__item-link active">Artikel</a>
                  </li>
                  <!-- /.nav-item -->
                  <li class="nav__item">
                    <a href="testimony" class="nav__item-link">Testimoni Pelanggan</a>
                  </li>
                  <!-- /.nav-item -->
                  <li class="nav__item">
                    <a href="galeri" class="nav__item-link">Galeri</a>
                  </li>
                  <!-- /.nav-item -->
                  <li class="nav__item">
                    <a href="kontak_kami" class="nav__item-link">Kontak Kami</a>
                  </li>
                  <!-- /.nav-item -->
                </ul>
                <!-- /.dropdown-menu -->
              </li>
            </ul>
            <!-- /.navbar-nav -->
            <button class="close-mobile-menu d-block d-lg-none">
              <i class="fas fa-times"></i>
            </button>
          </div>
          <!-- /.navbar-collapse -->
          <ul
            class="navbar-actions d-none d-xl-flex align-items-center list-unstyled mb-0">
            <!-- <li>
                <a href="#" class="btn btn__white action__btn login_btn"
                  >Login</a
                >
              </li> -->
            <li>
              <div class="phone__number">
                <div class="phone__icon">
                  <i class="icon-phone"></i>
                </div>
                <div>
                  <a class="phone__link d-block" href="tel:08111902759">0811 1902 759</a>
                  <a class="email__link d-block" href="mailto:cs@konig.co.id">cs@konig.co.id</a>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <!-- /.container -->
      </nav>
      <!-- /.navabr -->
    </header>
    <!-- /.Header -->

    <!-- ========================
       page title 
    =========================== -->
    <section
      class="page-title-layout3 page-title-light bg-overlay text-center">
      <div class="bg-img">
        <img src="assets/images/page-titles/pelatihan.jpg" alt="background" />
      </div>
      <div class="container">
        <div class="row">
          <div class="col-12">
            <h1 class="pagetitle__heading mb-0">Artikel</h1>
            <nav>
              <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="/">Beranda</a></li>
                <li class="breadcrumb-item active" aria-current="page">
                  Media &amp; Informasi
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Artikel
                </li>
              </ol>
            </nav>
          </div>
          <!-- /.col-12 -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container -->
    </section>
    <!-- /.page-title -->

    <!-- ======================
      Blog Grid
    ========================= -->

    <form class="search-container mt-30 mb-30" name="search" action="search.php" method="post">
      <input type="text" id="search-bar" name="searchtitle" placeholder="Artikel apa yang kamu cari?" required>
      <button class="search-icon" type="submit">
        <i class="fa-solid fa-magnifying-glass"></i>
      </button>
    </form>




    <section class="blog-grid">
      <div class="container">
        <div class="row">
          <!-- Post Item #1 -->
          <?php
          if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
          } else {
            $pageno = 1;
          }
          $no_of_records_per_page = 6;
          $offset = ($pageno - 1) * $no_of_records_per_page;


          $total_pages_sql = "SELECT COUNT(*) FROM tblposts";
          $result = mysqli_query($con, $total_pages_sql);
          $total_rows = mysqli_fetch_array($result)[0];
          $total_pages = ceil($total_rows / $no_of_records_per_page);


          $query = mysqli_query($con, "select tblposts.id as pid,tblposts.PostTitle as posttitle,tblposts.PostImage,tblcategory.CategoryName as category,tblcategory.id as cid,tblsubcategory.Subcategory as subcategory,tblposts.PostDetails as postdetails,tblposts.PostingDate as postingdate,tblposts.PostUrl as url from tblposts left join tblcategory on tblcategory.id=tblposts.CategoryId left join  tblsubcategory on  tblsubcategory.SubCategoryId=tblposts.SubCategoryId where tblposts.Is_Active=1 order by tblposts.id desc  LIMIT $offset, $no_of_records_per_page");
          while ($row = mysqli_fetch_array($query)) {

          ?>
            <div class="col-sm-12 col-md-6 col-lg-4">
              <div class="post-item">
                <div class="post__img">
                  <a href="artikel_detail.php?nid=<?php echo htmlentities($row['pid']) ?>">
                    <img
                      src="admin/postimages/<?php echo htmlentities($row['PostImage']); ?>"
                      alt="<?php echo htmlentities($row['posttitle']); ?>"
                      loading="lazy" />
                  </a>
                  <div class="post__meta-cat">
                    <a href="category?catid=<?php echo htmlentities($row['cid']) ?>"><?php echo htmlentities($row['category']); ?></a>
                  </div>
                  <!-- /.blog-meta-cat -->
                </div>
                <!-- /.post__img -->
                <div class="post__body">
                  <h4 class="post__title">
                    <a href="artikel_detail.php?nid=<?php echo htmlentities($row['pid']) ?>"><?php echo htmlentities($row['posttitle']); ?></a>
                  </h4>
                  <div class="post__meta d-flex">
                    <span class="post__meta-date">Terbit pada <?php echo htmlentities($row['postingdate']); ?></span>
                    <!-- <div class="post__meta-author">
                    <a href="#">John Ezak</a>
                  </div> -->
                  </div>
                  <p class="post__desc-index">
                    <?php
                    $text = str_replace(array('<p>', '</p>'), '', $row['postdetails']);

                    if (!isset($_GET['detail'])) {
                      // MODE INDEX
                      $maxLength = 300;
                      if (strlen($text) > $maxLength) {
                        $text = substr($text, 0, $maxLength) . '...';
                      }
                    }

                    echo $text;
                    ?>
                  </p>
                  <a
                    href="artikel_detail.php?nid=<?php echo htmlentities($row['pid']) ?>"
                    class="btn btn__secondary btn__outlined">
                    <i class="icon-arrow-right"></i>
                    <span>Read More</span>
                  </a>
                </div>
                <!-- /.post__body -->
              </div>
              <!-- /.post-item -->
            </div>
            <!-- /.col-lg-4 -->
          <?php } ?>
          <!-- /.row -->
          <div class="row">
            <div class="col-12 text-center">
              <nav class="pagination-area">
                <?php if ($total_pages > 1) { ?>
                  <ul class="pagination justify-content-center mb-0">

                    <!-- PREV -->
                    <li class="<?php echo ($pageno <= 1) ? 'disabled' : ''; ?>">
                      <a href="<?php echo ($pageno <= 1) ? '#' : '?pageno=' . ($pageno - 1); ?>">
                        <i class="icon-arrow-left"></i>
                      </a>
                    </li>

                    <!-- ANGKA -->
                    <?php for ($i = 1; $i <= $total_pages; $i++) { ?>
                      <li>
                        <a href="?pageno=<?php echo $i; ?>"
                          class="<?php echo ($pageno == $i) ? 'current' : ''; ?>">
                          <?php echo $i; ?>
                        </a>
                      </li>
                    <?php } ?>
                  </ul>
                <?php } ?>
                </ul>
              </nav>
              <!-- .pagination-area -->
            </div>
            <!-- /.col-12 -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>
    <!-- /.blog Grid -->

    <!-- ========================
      Footer
    ========================== -->
    <footer class="footer">
      <div class="footer-primary">
        <div class="container">
          <div class="row">
            <div class="col-sm-6 col-md-4 col-lg-4">
              <div class="footer-widget-contact">
                <!-- <h6 class="footer-widget__title">Quick Contacts</h6> -->
                <h5 class="ft-title">ABOUT <span>US</span></h5>

                <a href="/"><img
                    src="assets/images/logo/logo_terang.png"
                    class="mb-20 w-100 h-60"
                    alt="logo-footer" /></a>
                <p>
                  PT. KONIG GUARD BUREAU adalah Perusahaan Penyedia Jasa
                  Outsourcing yang menghadirkan layanan Security, Cleaning
                  Service, Administrasi, dan Driver untuk lingkungan kerja
                  yang AMAN, NYAMAN, dan PROFESIONAL.
                </p>
                <ul class="contact__list list-unstyled">
                  <li>
                    <a href="mailto:cs@konig.co.id">
                      <i class="contact__icon icon-email"></i>
                      <span>cs@konig.co.id</span>
                    </a>
                  </li>
                  <li>
                    <a href="tel:08111902759">
                      <i class="contact__icon icon-phone"></i>
                      <span>(+62) 811 1902 759</span>
                    </a>
                  </li>
                </ul>
                <p>Puri Botanical Residence Blok H9 No.11, Jakarta - Indonesia.</p>
                <a
                  href="kontak_kami"
                  class="btn btn__white btn__link mr-30">
                  <i class="fas fa-map-marker-alt"></i>
                  <span>Get Directions</span>
                </a>
              </div>
              <!-- /.footer-widget-contact -->
              <ul
                class="social-icons list-unstyled justify-content-start mb-0">
                <li>
                  <a href="#"><i class="fab fa-linkedin"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fab fa-instagram"></i></a>
                </li>
              </ul>
            </div>
            <!-- /.col-xl-2 -->
            <div class="col-sm-6 col-md-4 col-lg-2 offset-lg-3">
              <div class="footer-widget-nav">
                <!-- <h6 class="footer-widget__title">Services</h6> -->
                <h5 class="ft-title">QUICK <span>LINK</span></h5>
                <nav>
                  <ul class="list-unstyled">
                    <li>
                      <a href="siapa_kami">Siapa Kami</a>
                    </li>
                    <li><a href="legalitas">Legalitas Perusahaan</a></li>
                    <li><a href="struktur">Struktur Perusahaan</a></li>
                    <li><a href="galeri">Dokumentasi Perusahaan</a></li>
                    <li>
                      <a href="jasa_keamanan">Layanan Keamanan Kami</a>
                    </li>
                    <li>
                      <a href="jasa_operasional">Layanan Fasilitas &amp; Kami</a>
                    </li>
                    <li><a href="karir">Karir</a></li>
                  </ul>
                </nav>
              </div>
              <!-- /.footer-widget-nav -->
            </div>
            <!-- /.col-lg-2 -->
            <div class="col-sm-6 col-md-4 col-lg-3">
              <div class="footer-widget-nav">
                <!-- <h6 class="footer-widget__title">Help</h6> -->
                <h5 class="ft-title">MITRA &amp; <span>TRAINING</span></h5>
                <nav>
                  <ul class="list-unstyled">
                    <li><a href="mitra_konig">Mitra Pengamanan</a></li>
                    <li>
                      <a href="mitra_pelatihan">Mitra Pelatihan</a>
                    </li>
                    <li>
                      <a href="pelatihan_konig">Pelatihan Khusus</a>
                    </li>
                    <li><a href="kontak_kami">Kontak Kami</a></li>
                  </ul>
                </nav>
              </div>
              <!-- /.footer-widget-nav -->
            </div>
            <!-- /.col-lg-2 -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container -->
      </div>
      <!-- /.footer-primary -->
      <div class="footer-scroll text-center"></div>
      <!-- /.footer-scroll -->
      <div class="footer-secondary bg-white">
        <div class="container">
          <div class="row align-items-center">
            <div
              class="col-sm-12 col-md-8 col-lg-12 col-xl-8 offset-xl-2 d-flex flex-wrap justify-content-between align-items-center">
              <div class="footer__copyrights">
                <span class="fz-14">&copy; 2025 Konig Guard Bureau, All Rights Reserved
                </span>
              </div>
            </div>
            <!-- /.col-xl-10 -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container -->
      </div>
      <!-- /.footer-secondary -->
    </footer>
    <!-- /.Footer -->
  </div>
  <!-- /.wrapper -->
  <div class="cursor"></div>
  <!-- scrollUp btn -->
  <div class="progress-wrap">
    <svg
      class="progress-circle svg-content"
      width="100%"
      height="100%"
      viewBox="-1 -1 102 102">
      <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
    </svg>
  </div>

  <script src="assets/js/jquery-3.5.1.min.js"></script>
  <script src="assets/js/plugins.js"></script>
  <script src="assets/js/main.js"></script>
  <script src="assets/js/script.js"></script>
</body>

</html>